Plugin Information
--------------------
Plugin Name: Jdownload
Author: wftpserver
Author Website: http://www.wftpserver.com
Current Version: 1.5


Description
--------------------
This plugin uses jdownload applet for downloading entire folder or files.


Installation
--------------------
Just download the zip file, and extract it into the directory "webclient/plugins/", then there will be a directory "webclient/plugins/jdownload".


History
----------------------------------------------------
Version 1.0	[25/Apr/2011]
* The first working version

Version 1.1	[25/May/2011]
* Fixed a bug - can not download the files under the virtual directory.

Version 1.2	[21/Aug/2013]
* Fixed a bug - download freeze issue when applying the new JAVA update.
* Improved the compatibility for most web browsers.
* Added a feature - remember the latest "Save to folder".
* Added a feature - support right-clicking on a file ( or a folder).

Version 1.3	[29/May/2015]
* Signed the file "jdownload.jar"
* Added multiple languages for this web client plugin.

Version 1.4	[12/Jun/2015]
* Cannot download the file when file name contains special characters.
* Cannot download the folder when folder name contains special characters.

Version 1.5	[30/Oct/2015]
* When downloading some special folder, it won't release the file handles.
* Even the web client uses 'HttpOnly' cookies, the plugin can still work.