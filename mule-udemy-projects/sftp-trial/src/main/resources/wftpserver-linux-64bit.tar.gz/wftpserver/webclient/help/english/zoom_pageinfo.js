pageinfo = [[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null]];
pagedata = [ ["requirements.htm","Using the web client &#62; Quick Guide","Quick Guide",""],
["uoeoeia.htm","Using the web client &#62; Overview","Overview",""],
["using_picture_viewer.htm","Using the web client &#62; Using Picture Viewer","Using Picture Viewer",""],
["using_text_editor.htm","Using the web client &#62; Using Text Editor","Using Text Editor",""]];
